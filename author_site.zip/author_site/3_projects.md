---
layout: default
title: My Projects
permalink: /my_projects/
---

<h2>Projects</h2>
<ul>
  {% assign sorted_projects = site.posts | where: "categories", "project" | sort: "weight" %}
  {% for project in sorted_projects %}
    <li>
      <a href="{{ project.url }}">{{ project.title }}</a> - {{ project.date | date: "%B %d, %Y" }}
    </li>
  {% endfor %}
</ul>