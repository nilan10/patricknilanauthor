---
layout: default
title: Sci-Fi
category: short-stories
menu: false
permalink: /scifi/
---

<h2>Sci-Fi Stories</h2>
<ul>
  {% for post in site.posts %}
    {% if post.categories contains "Scifi" %}
      <li>
        <a href="{{ post.url }}">{{ post.title }}</a> - {{ post.date | date: "%B %d, %Y" }} 
        ({{ post.categories | join: ", " }}) <!-- To list the genres -->
      </li>
    {% endif %}
  {% endfor %}
</ul>