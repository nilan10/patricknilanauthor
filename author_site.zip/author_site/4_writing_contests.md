---
layout: default
title: Writing Contests
permalink: /contests/
---

<h2>Writing Contests</h2>
<ul>
  {% for post in site.posts %}
    {% if post.categories contains "contest" %}
      <li>
        <a href="{{ post.url }}">{{ post.title }}</a> - {{ post.date | date: "%B %d, %Y" }}
      </li>
    {% endif %}
  {% endfor %}
</ul>
