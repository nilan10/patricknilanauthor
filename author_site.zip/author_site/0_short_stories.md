---
layout: default
title: Short Stories
permalink: /short_stories/
---



<h2>Short Stories</h2>
<ul>
  {% for post in site.posts %}
    {% if post.categories contains "short-story" %}
      <li>
        <a href="{{ post.url }}">{{ post.title }}</a> - {{ post.date | date: "%B %d, %Y" }} 
        ({{ post.categories | join: ", " }}) <!-- To list the genres -->
      </li>
    {% endif %}
  {% endfor %}
</ul>
