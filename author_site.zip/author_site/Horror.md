---
layout: default
title: Horror
category: short-stories
menu: false
permalink: /horror/
---

<h2>Horror Stories</h2>
<ul>
  {% for post in site.posts %}
    {% if post.categories contains "Horror" %}
      <li>
        <a href="{{ post.url }}">{{ post.title }}</a> - {{ post.date | date: "%B %d, %Y" }} 
        ({{ post.categories | join: ", " }}) <!-- To list the genres -->
      </li>
    {% endif %}
  {% endfor %}
</ul>