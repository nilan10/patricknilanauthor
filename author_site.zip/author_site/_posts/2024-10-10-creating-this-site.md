---
layout: post
title: "Creating This Very Website"
date: 2024-10-10
categories: project
weight: 1
tags: [development, programming]
excerpt: "Creating this site was a lot more work then I anticipated, but it was certainly wourth it!"
---

When I first came up with the idea to build this site, I thought it would take about 15 hours and be a nice, easy project for my resume. Well, that’s not exactly how things went...

Even though hosting an author site on a Raspberry Pi 4 can seem intimidating, as a computer engineering graduate, the concept didn’t faze me. The hardware setup went smoothly except for the fan that came with the kit, which didn’t work (don’t even get me started). As I entered the bash commands to download Jekyll, I started to feel like the project was too simple, and I wondered if it was even worth putting on my resume.

That feeling didn’t last long. A day into it, after downloading the Jekyll template, I figured the rest would be plug-and-play. Wrong!

When you hear "template," you expect it to make life easier. Considering the struggle I went through with the simplest template I could find, I can’t imagine how hard it would’ve been without one. What I thought would be a “simple” 15-hour project quickly became the only thing I thought about for an entire week. I started obsessing over every little detail, like playing with fonts and text sizes in the CSS file, and wasted hours trying to perfect the smallest of details. More often than not, when I tried to make changes, I’d accidentally completely break the site or at the very least make it much worse. At one point, I changed the main menu, only to make the mobile version look like absolute crap. Six hours of work just to end up restoring the default files.

After spending so much time spinning my wheels, I remembered something from my business courses: focus on creating a minimum viable product (MVP). I narrowed my priorities to displaying posts (blog ,stories, contests, projects), linking to my social media pages, collecting emails for my newsletter, and having a clean menu so the user can access all the features.

Even that MVP was a lot harder than I expected it would be. A task as simple as displaying an image on my About page became a headache when I didn’t realize that underscores are a special character in Jekyll, and I had named my images folder "_images." In hindsight I probably should have read the README…

Learning to display posts in different orders was a real challenge. While not essential to the MVP the idea was that while it was ideal for the blog to be organized by date it made sense to organize the project posts based on how serious I am about them. I would not want a post on Operation Ark to be buried by yet another one of my strange side quests…

 I thought I was done at one point and was ready to celebrate, only to find six extra dividers in my main menu with no categories between them. Even with tutorials and ChatGPT, fixing that error was brutal. Just explaining the issue to the AI took some skill on my behalf.
Once I had the MVP working, I decided to add a feature on my own without help: a popup menu for story genres. It took forever, and I nearly gave up multiple times, but I eventually got it working, and I was proud of myself when I did.

This site is far from perfect, and as I grow as an author, I expect it to grow with me. As I become more familiar with HTML, CSS, and web development, I’m sure each version of this site will be better than the last. I can not wait for the day where I add a new section for Books on the menu once Operation Ark is finally published!

So, was this project worth the $100 or so I’m saving by not using WordPress? Monetarily, absolutely not. I’m lucky I didn’t blow those savings by punching my monitor at points working on this.
Still, if I had to choose again, I’d take on the experience of building my own site. I learned a ton about web development, Raspberry Pi 4 hardware, HTML, CSS, markdown, Jekyll, and nginx. Most importantly, every time I glance at the Raspberry Pi 4 sitting behind my monitors, I’m filled with a sense of accomplishment.

I built this—just like I build the worlds my stories explore.