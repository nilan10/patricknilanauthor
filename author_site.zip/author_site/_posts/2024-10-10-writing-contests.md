---
layout: post
title: "Future Writing Contest"
date: 2024-10-10
categories: contest
tags: [contest, writing]
excerpt: "A look ahead at my next writing contest!"
---

I absolutely love writing contests. Whether I'm entering one, hosting, or judging for someone else, there's something about the competition that excites me.

Having my own site is the perfect opportunity to host more contests, and I plan to take full advantage of that. My first writing contest on this site will be when I reach 100K followers on Instagram—a great way to thank my supporters and celebrate what @memesforwriters is all about.

The themes of future contests will usually align with the projects I'm working on at the time. While sci-fi is my favorite genre, I won't limit submissions to it. One of the best parts of hosting writing contests is exploring genres and themes outside my comfort zone.

When judging, I will always treat each entry fairly. The only thing that matters is the quality of the writing on the page, just as I hope my entries are judged when I participate in contests.

If you're interested in teaming up to run a contest, feel free to reach out. I typically collaborate with larger creators to reach a bigger audience, but I'm open to working with anyone interested in judging or suggesting themes.