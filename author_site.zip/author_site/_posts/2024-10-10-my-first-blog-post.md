---
layout: post
title: "I Don't Know What I'm Doing..."
date: 2024-10-10
categories: blog
tags: [introduction, personal]
excerpt: "In many aspects of my life I have absolutely no clue what I'm doing, but I still try!"
---

I don’t know what the fuck I’m doing… That is a thought that relates to many aspects of my life right now. Even writing this blog post I find myself thinking about how I have no clue how to write a quality blog post. At this moment I am actually writing this post rather than finishing up the setup for this very site because… well because when it comes to building a website from scratch using Jekyll and hosting it on a Raspberry Pi 4 I don’t know what the fuck I’m doing.

Is it a bad idea to use the F word three times on the first page of your author site? Probably… Perhaps it ruins your SEO or your credibility with your audience. To be honest, I wouldn’t know because… well, I think you get the point by now.

As a kid I liked to think I knew everything there was to know, and if there was something I didn’t know it would only be a matter of time before I learned it. Writing this at age 23 I realize that could not be further from the truth. I’d like to think I know more than the average person, but I’m pretty sure we all think that. By that logic some of us have to be wrong, not that there’s necessarily anything wrong with that.

These days there seems to be an increasing pressure not to be wrong and not to make mistakes. I can’t tell you how many times I looked up an answer in school, not because I was lazy, but because I was not sure of my answer and I didn’t want to get it wrong. In school when you get a question wrong, when you make a mistake, you lose points. You get punished!

In hindsight perhaps that punishment wasn’t really that big of a deal, but back in high school and college, the difference between an A- and a C+ seemed like the end of the world. In my head that A- would earn me a well-paying job and that C+ would earn me a life on the streets. 

Well, I graduated with that A- GPA and I still don’t know what the fuck I’m doing. It's been more than 4 months since I graduated and I've only landed one interview (I was dismissed after taking an hour-long test because I did not have the knowledge they were looking for). I do not blame the company (although I will say they could have been nice about it). The truth is after four years of studying computer engineering and a year of studying for my MBA I feel like I don't know anything. The more I seem to learn about any topic from writing a Sci-Fi book to computer engineering (which I majored in) the more I realize just how much more there is that I don't know.

That can be scary. To my younger self, there was nothing more terrifying than the unknown. That idea that I knew everything acted like a safe space within my mind. It’s similar to advice like “write what you know” or “stick to your strengths.” There’s less risk of making mistakes when you do things you’re comfortable with. The thing is mistakes aren’t necessarily the awful thing they are made out to be.

As a writer, I can honestly say I don’t think I’ve learned a ton about writing a story from reading from the greats and studying literature. I’ve learned the majority of what I know about writing, and I’ll be the first to admit it’s not a lot, from creating abominable works of fan fiction and brutal rough drafts of my overly ambitious projects that I still hardly know how to start. 

Specifically, I feel I’ve learned the most from projects where I stepped directly into the unknown. Earlier in my writing career, I would put some of my more ambitious book ideas on hold because I had no fucking clue how to write them. For a new writer, stories involving time loops, digital realities, and vast galactic empires can feel daunting, so I tried to start by writing simpler, safer stories instead. The idea was to write a story that I knew I could write to make myself comfortable. Writing these simpler stories I’ve found being comfortable is the enemy of creativity.

Writing my debut novel has as a result been anything but a comfortable experience. My plans for my debut novel are ambitious. At points attempting to write "Operation Ark"(title in progress), I've found myself taking a step back and acknowledging I have no clue how to write this damn book. There are far easier debut novels to write than a series of interconnected short stories about humans attempting to survive a nuclear apocalypse on space stations that are secretly genetic testing facilities. This project may end up being a complete colossal disaster, but I'm willing to take that risk. In the best-case scenario, I create something my audience loves and can act as if I knew exactly what I was doing all along. If it flops then hopefully I'll learn something from the experience so I have a bit better of an idea of what I'm doing for my second novel. The only time mistakes are costly as a creator is when they cause you to give up.

This website is not the first author site I've attempted to create. While my first site was anything but an attempt at playing things safe the blog posts I created were. They were bland, well-polished, and EXTREMELY FUCKING BORING. I focused so hard on making them read professionally that they no longer had my voice. 

As you can see with this blog I am going a bit of a different route. Finishing up writing this blog post I wonder if I may have pushed it too far. The F word kind of loses its effect after the first five or so times you spam it on the page. The idea of putting this internet makes me a bit nervous. While it's not the end of the world if people don't like this style I'm definitely taking a chance posting this. That's a good thing.

To create anything worth creating you need to take chances. How many best-selling books or games do you think were created by people playing them safely? As I like to think, when you write something to please everyone you end up pleasing nobody.

So yeah, I don’t know what the fuck I’m doing, but I’d like to think that means I’m doing something right!
