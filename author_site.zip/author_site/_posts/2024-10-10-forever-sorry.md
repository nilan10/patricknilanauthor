---
layout: post
title: "Forever Sorry"
date: 2024-10-10
categories: [short-story,Horror]
tags: [contest, writing]
excerpt: "A man spends an eternity reliving his crime..."
---

**Author:** Patrick Nilan

**Word Count:** 100

---

## Forever Sorry

With a gasp, I awake. I am paralyzed with fear, but I can not recall why. No thoughts exist within my mind.

Eventually, I sit up as the hairs on my arm settle. The room is familiar, but something is off. The exit is missing.

Then Angela’s scream pierces my eardrums. Her decaying corpse lunges out from the closet as it always does. 

In the moment before she claws into my flesh and I lie bleeding out I remember. Angela’s murder. My sentence. The machine. How many times have I died for my crime?

With a gasp, I awake.
