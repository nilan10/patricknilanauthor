---
layout: default
title: About Me
permalink: /about/
---

# About Me

![Patrick Nilan](../images/Patrick_Nilan_Headshot.jpeg)

My name is Patrick Nilan and I am a 23 year old aspiring author, game developer, content creator, and an expert procrastinator. The expert procrastinator part explains why I have to put "Aspiring" before "Author"...

From an early age I knew I had a love for telling stories. The lore me and my sister crafted for our toys was outstanding! That being said it was not until I started posting writing memes on Instagram that I started to take this whole writing thing "seriously". I put that in quotes because I'm a person who tries not to take life too seriously. 

Beyond my creative passions I have a computer engineering degree and MBA from Binghamton University. While I do not have a job at the moment I spend the majority of my time stressing over the New York Islanders and working on various projects from my first novel to designng this website from scratch (hopefully that will help land me a job)!

To be honnest the About page is a pretty awkward place to get to know someone. Checking out some of my post or my social media platforms below is a much better way to get to know me. Don't be afraid to reach out!

### Stay Connected

**Professional Email:** [patricknilanofficial@gmail.com](mailto:patricknilanofficial@gmail.com)

---

### Social Media - Writing Journey

- **Instagram:** [memesforwriters](https://www.instagram.com/memesforwriters)
- **TikTok:** [memes4writers](https://www.tiktok.com/@memes4writers)
- **YouTube:** [Patrick Nilan](https://www.youtube.com/@patrick_nilan)

---

### Game Development

- **Instagram:** [patcavestudio](https://www.instagram.com/patcavestudio)
- **TikTok:** [patcavestudio](https://www.tiktok.com/@patcavestudio)
- **YouTube:** [Patcave Studio](https://www.youtube.com/@patcavestudio)

---

### Wattpad Stories

Check out my Wattpad account where I share stories. Note the stories on my Wattpad are really bad. A lot of them are results of challenges (such as my challenge to write a book in a week) and do not quite represent what I believe I am capable of as a writer. Still, I'll leave it here because it's still my writing and I do sort of like some of it. Have Fun: [nilan10](https://www.wattpad.com/user/nilan10)

---

Stay tuned for updates on my writing projects, short stories, and game development!
